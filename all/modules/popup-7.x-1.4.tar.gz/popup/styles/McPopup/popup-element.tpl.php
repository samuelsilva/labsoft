<div id="<?php print $css_id;?>" class="<?php print $class;?>">
  <?php print $title; ?>
  <?php print $body; ?>
</div>