<?php
/*

The following variables are available:
  $class - CSS class of the title
  $title - Popup title text

*/
?>

<a <?php print $href;?> class="<?php print $class;?>"><?php print $title; ?></a>